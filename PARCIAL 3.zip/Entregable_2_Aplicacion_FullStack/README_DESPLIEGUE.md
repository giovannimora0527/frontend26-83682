# ENTREGABLE 2: DESPLIEGUE FULL STACK EN DOCKER Y DOCKER COMPOSE

## Estructura de Contenedores
* `mysql-db`: Base de datos MySQL 8.4 inicializada automáticamente con `01_script_bd_clinica_veterinaria.sql`.
* `backend-api`: API REST desarrollada en Java 21 + Spring Boot (Spring Security + JWT + JPA + Apache POI + OpenPDF + Swagger).
* `frontend-web`: Aplicación Angular servida con Nginx y proxy inverso hacia `/api/`.

## Instrucciones Rápidas
1. Ubicar la carpeta `backend/` (con el `pom_completo_recomendado.xml` renombrado a `pom.xml` y `Dockerfile_backend` como `Dockerfile`) y la carpeta `frontend/` (con `Dockerfile_frontend` como `Dockerfile` y `nginx.conf`).
2. Ejecutar en la raíz donde está `docker-compose.yml`:
   ```bash
   docker compose up -d --build
   ```
3. Verificar estado de los 3 servicios:
   ```bash
   docker compose ps
   ```
