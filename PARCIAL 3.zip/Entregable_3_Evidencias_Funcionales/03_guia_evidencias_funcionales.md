# ENTREGABLE 3: GUÍA DE EVIDENCIAS FUNCIONALES (5 ESCENARIOS OBLIGATORIOS)

Adjunte las capturas de pantalla de su aplicación ejecutando cada uno de los 5 escenarios con los datos de prueba detallados a continuación. El archivo `plantilla_carga_masiva_55_registros.xlsx` incluido en esta carpeta ya contiene **55 registros listos** para ejecutar la prueba 1.

---

## Evidencia 1: Carga Masiva de Inventario (> 50 Registros)
* **Archivo a cargar:** `plantilla_carga_masiva_55_registros.xlsx` (55 ítems entre medicamentos con registro INVIMA obligatorio e insumos sin INVIMA).
* **Capturas requeridas:**
  1. Pantalla de **vista previa** mostrando los 55 registros validados antes de confirmar.
  2. Prueba negativa (modificando 2 filas en una copia con código duplicado o fecha vencida) mostrando el **informe de errores por fila y motivo** sin bloquear los registros válidos.
  3. Confirmación de importación y registro en el **Log de Cargue** (usuario, fecha, 55 válidos).

## Evidencia 2: Descuento de Inventario mediante Dispensación (`DESPACHO_MEDICO`)
* **Flujo a capturar:**
  1. Inicio de sesión con usuario `despacho.vet` (verificando que el menú oculta citas, historias clínicas, facturación y edición de inventario).
  2. Selección de fórmula médica pendiente y validación de lotes vigentes priorizados por **FEFO** (vencimiento más próximo).
  3. Confirmación de despacho, descarga del **Comprobante de Dispensación en PDF** y consulta del **Kardex / Movimientos de Inventario** evidenciando el descuento exacto y el usuario responsable.

## Evidencia 3: Gestión de Citas Médicas mediante Calendario (`VETERINARIO` vs `SECRETARIA`)
* **Flujo a capturar:**
  1. Vista de calendario del veterinario (`dr.ramirez`) en modos **Día, Semana y Mes** con colores por estado (`PENDIENTE`, `CONFIRMADA`, `CANCELADA`, `FINALIZADA`).
  2. Intento de crear cita superpuesta o fuera de horario mostrando el bloqueo de regla de negocio.
  3. Exportación del reporte de citas en **Excel (`.xlsx`)** filtrado por rango de fechas.

## Evidencia 4: Atención Médica, Fórmulas Médicas y Facturación en PDF
* **Flujo a capturar:**
  1. Registro de atención clínica (motivo, síntomas, diagnóstico, observaciones y recomendaciones) asociada al historial de la mascota.
  2. Emisión de **Fórmula Médica en PDF** y **Prefactura en PDF**.
  3. Emisión de **Factura en PDF** (cobrando únicamente consulta + medicamentos efectivamente dispensados) y registro de pago (`PAGO_PARCIAL` -> `PAGADA`).

## Evidencia 5: Reportes Administrativos, Contables y de Inventario (PDF y Excel)
* **Flujo a capturar:**
  1. Filtro por rango de fechas y vista previa de reportes financieros (ingresos por período, especialidad y veterinario), de inventario (valorización a costo y venta, stock mínimo, próximos a vencer) y de gestión médica.
  2. Descarga y visualización de los documentos exportados en **PDF** y **Excel (`.xlsx`)** con encabezados, fecha de generación y totales.
