# ENTREGABLE 1: MODELO DE DATOS ACTUALIZADO
**Proyecto:** Sistema de Gestión Administrativa, Médica y Financiera — Clínica Veterinaria Uniminuto  
**Asignatura:** Programación Web Full Stack  

---

## 1. Diagrama Entidad-Relación (DER) Actualizado

```mermaid
erDiagram
    ROL ||--o{ USUARIO : "asigna"
    USUARIO ||--o| VETERINARIO : "perfil_medico"
    ESPECIALIDAD ||--o{ VETERINARIO : "pertenece"
    VETERINARIO ||--o{ HORARIO_DISPONIBILIDAD_VETERINARIO : "define"

    PROPIETARIO ||--o{ MASCOTA : "posee"
    ESPECIALIDAD ||--o{ TARIFA_SERVICIO : "tarifa"
    TARIFA_SERVICIO ||--o{ LOG_CAMBIO_TARIFA : "audita"

    MASCOTA ||--o{ CITA_MEDICA : "agenda"
    PROPIETARIO ||--o{ CITA_MEDICA : "solicita"
    VETERINARIO ||--o{ CITA_MEDICA : "atiende"
    ESTADO_CITA ||--o{ CITA_MEDICA : "clasifica"
    TARIFA_SERVICIO ||--o{ CITA_MEDICA : "cotiza"

    CITA_MEDICA ||--o| ATENCION_MEDICA : "genera"
    ATENCION_MEDICA ||--o{ FORMULA_MEDICA : "prescribe"
    FORMULA_MEDICA ||--|{ DETALLE_FORMULA_MEDICA : "contiene"

    MEDICAMENTO ||--o{ MEDICAMENTO_LOTE : "controla_lotes"
    MEDICAMENTO ||--o{ DETALLE_FORMULA_MEDICA : "se_formula"
    FORMULA_MEDICA ||--o{ DESPACHO_MEDICAMENTO : "se_dispensa"
    DESPACHO_MEDICAMENTO ||--|{ DETALLE_DESPACHO_MEDICAMENTO : "entrega_lote"
    MEDICAMENTO_LOTE ||--o{ DETALLE_DESPACHO_MEDICAMENTO : "descuenta"

    MEDICAMENTO ||--o{ MOVIMIENTO_INVENTARIO : "kardex"
    DESPACHO_MEDICAMENTO ||--o{ MOVIMIENTO_INVENTARIO : "origina_salida"
    FORMULA_MEDICA ||--o{ LOG_ESTADO_DESPACHO : "traza_estados"

    CITA_MEDICA ||--o| FACTURA : "factura_unica"
    FACTURA ||--|{ DETALLE_FACTURA : "detalla"
    FACTURA ||--o{ PAGO_FACTURA : "recauda"
```

---

## 2. Justificación Técnica de los Cambios Realizados

1. **Evolución de la tabla `medicamento` hacia multi-lote (`medicamento` + `medicamento_lote`):**
   * La tabla original únicamente permitía una `fecha_compra` y una `fecha_vence` global por medicamento. El requerimiento 1.2 exige soportar **múltiples lotes, distintos precios de adquisición y diferentes fechas de vencimiento** para un mismo producto, además de priorización **FEFO** (*First Expired, First Out*) en despacho (Req. 5.3).
   * Se añadió `codigo` con restricción `CHAR_LENGTH(codigo) = 8` y `UNIQUE`, `tipo_producto` (`MEDICAMENTO` vs. `UTENSILIO_INSUMO`) para exigir `registro_invima` solo en medicamentos (Req. 1.1), `stock_minimo`, `fecha_ingreso_inventario` y `fecha_proximo_pedido`.

2. **Separación estricta entre Formulación y Dispensación (`formula_medica` vs. `despacho_medicamento`):**
   * Para garantizar que la prescripción médica **no** afecte el stock hasta que el perfil `DESPACHO_MEDICO` confirme la entrega (Req. 1.3 y 5.8), se separó `detalle_formula_medica` (`cantidad_prescrita` vs `cantidad_dispensada`) de `despacho_medicamento` y `detalle_despacho_medicamento` (que vincula el lote exacto).
   * La tabla `movimiento_inventario` registra el Kardex completo (`stock_anterior`, `stock_nuevo`, `usuario_id`, `formula_id`, `despacho_id`) con índice único `uk_mov_unico_despacho_lote` que impide descontar dos veces el mismo despacho.

3. **Agenda Médica Relacional (`veterinario`, `horario_disponibilidad_veterinario`, `cita_medica`, `estado_cita`):**
   * Reemplaza cualquier vista estática en interfaz conectando la cita con mascota, propietario, veterinario, especialidad, tarifa y estado, permitiendo validar en backend que no existan solapamientos de horario ni citas a médicos inactivos (Req. 2.3 y 2.4).

4. **Facturación Histórica Inmutable y Auditoría (`tarifa_servicio`, `log_cambio_tarifa`, `factura`, `detalle_factura`, `pago_factura`):**
   * `detalle_factura` guarda `precio_unitario_historico` y `porcentaje_iva_historico` para que modificaciones posteriores en `tarifa_servicio` no alteren facturas emitidas (Req. 3.5).
   * La restricción `UNIQUE KEY uk_factura_cita (cita_id)` impide cobrar dos veces el mismo servicio por una misma atención, y la anulación funciona por cambio de estado (`ANULADA`) con motivo, usuario y fecha sin borrar registros.

---

## 3. Archivo SQL Adjunto
* Ejecute `01_script_bd_clinica_veterinaria.sql` incluido en esta carpeta para crear la base de datos completa con todas las llaves foráneas, restricciones `CHECK`, índices y datos semilla de roles y estados.
