-- ============================================================================
-- SCRIPT SQL: SISTEMA INTEGRAL CLÍNICA VETERINARIA UNIMINUTO
-- Motor: MySQL 8.0+ | Charset: utf8mb4
-- ============================================================================

CREATE DATABASE IF NOT EXISTS clinica_veterinaria_uniminuto
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE clinica_veterinaria_uniminuto;

-- ----------------------------------------------------------------------------
-- 1. SEGURIDAD, ROLES Y USUARIOS (Req. 2, 4, 5)
-- ----------------------------------------------------------------------------
CREATE TABLE rol (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(40) NOT NULL, -- ADMIN, SECRETARIA, VETERINARIO, DESPACHO_MEDICO
  nombre VARCHAR(80) NOT NULL,
  descripcion VARCHAR(255) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_rol_codigo (codigo)
) ENGINE=InnoDB;

CREATE TABLE usuario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  rol_id BIGINT UNSIGNED NOT NULL,
  documento VARCHAR(30) NOT NULL,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL,
  username VARCHAR(60) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_actualizacion DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_usuario_documento (documento),
  UNIQUE KEY uk_usuario_email (email),
  UNIQUE KEY uk_usuario_username (username),
  CONSTRAINT fk_usuario_rol FOREIGN KEY (rol_id) REFERENCES rol(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 2. ESPECIALIDADES, VETERINARIOS, DISPONIBILIDAD Y TARIFAS (Req. 2 y 3.1)
-- ----------------------------------------------------------------------------
CREATE TABLE especialidad (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  nombre VARCHAR(100) NOT NULL,
  descripcion TEXT NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_modificacion DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_especialidad_codigo (codigo),
  UNIQUE KEY uk_especialidad_nombre (nombre)
) ENGINE=InnoDB;

CREATE TABLE veterinario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id BIGINT UNSIGNED NOT NULL,
  especialidad_id BIGINT UNSIGNED NOT NULL,
  tarjeta_profesional VARCHAR(50) NOT NULL,
  telefono VARCHAR(30) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_veterinario_usuario (usuario_id),
  UNIQUE KEY uk_veterinario_tp (tarjeta_profesional),
  CONSTRAINT fk_vet_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id),
  CONSTRAINT fk_vet_especialidad FOREIGN KEY (especialidad_id) REFERENCES especialidad(id)
) ENGINE=InnoDB;

CREATE TABLE horario_disponibilidad_veterinario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  veterinario_id BIGINT UNSIGNED NOT NULL,
  dia_semana TINYINT NOT NULL COMMENT '1=Lunes ... 7=Domingo',
  hora_inicio TIME NOT NULL,
  hora_fin TIME NOT NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  CONSTRAINT chk_horario_vet CHECK (hora_fin > hora_inicio AND dia_semana BETWEEN 1 AND 7),
  CONSTRAINT fk_horario_vet FOREIGN KEY (veterinario_id) REFERENCES veterinario(id)
) ENGINE=InnoDB;

CREATE TABLE tarifa_servicio (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(20) NOT NULL,
  nombre_servicio VARCHAR(120) NOT NULL,
  tipo_servicio ENUM('CONSULTA', 'PROCEDIMIENTO', 'CIRUGIA', 'VACUNACION', 'OTRO') NOT NULL DEFAULT 'CONSULTA',
  especialidad_id BIGINT UNSIGNED NULL,
  valor_base DECIMAL(12,2) NOT NULL,
  porcentaje_iva DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_modificacion DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_tarifa_codigo (codigo),
  CONSTRAINT chk_tarifa_valor CHECK (valor_base >= 0 AND porcentaje_iva >= 0),
  CONSTRAINT fk_tarifa_especialidad FOREIGN KEY (especialidad_id) REFERENCES especialidad(id)
) ENGINE=InnoDB;

CREATE TABLE log_cambio_tarifa (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tarifa_id BIGINT UNSIGNED NOT NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  valor_anterior DECIMAL(12,2) NOT NULL,
  valor_nuevo DECIMAL(12,2) NOT NULL,
  iva_anterior DECIMAL(5,2) NOT NULL,
  iva_nuevo DECIMAL(5,2) NOT NULL,
  motivo VARCHAR(255) NULL,
  fecha_cambio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_log_tarifa FOREIGN KEY (tarifa_id) REFERENCES tarifa_servicio(id),
  CONSTRAINT fk_log_tarifa_user FOREIGN KEY (usuario_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 3. PROPIETARIOS, MASCOTAS Y CITAS MÉDICAS (Req. 2 y Nota Final)
-- ----------------------------------------------------------------------------
CREATE TABLE propietario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  tipo_documento ENUM('CC', 'CE', 'NIT', 'PASAPORTE') NOT NULL DEFAULT 'CC',
  numero_documento VARCHAR(30) NOT NULL,
  nombres VARCHAR(100) NOT NULL,
  apellidos VARCHAR(100) NOT NULL,
  telefono VARCHAR(30) NOT NULL,
  email VARCHAR(150) NULL,
  direccion VARCHAR(200) NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_propietario_doc (tipo_documento, numero_documento)
) ENGINE=InnoDB;

CREATE TABLE mascota (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  propietario_id BIGINT UNSIGNED NOT NULL,
  nombre VARCHAR(80) NOT NULL,
  especie VARCHAR(50) NOT NULL,
  raza VARCHAR(80) NULL,
  sexo ENUM('MACHO', 'HEMBRA') NOT NULL,
  fecha_nacimiento DATE NULL,
  peso_kg DECIMAL(6,2) NULL,
  color VARCHAR(60) NULL,
  alergias_antecedentes TEXT NULL,
  activa TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_mascota_propietario FOREIGN KEY (propietario_id) REFERENCES propietario(id)
) ENGINE=InnoDB;

CREATE TABLE estado_cita (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(30) NOT NULL, -- PENDIENTE, CONFIRMADA, CANCELADA, FINALIZADA
  nombre VARCHAR(60) NOT NULL,
  color_hex VARCHAR(10) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_estado_cita_codigo (codigo)
) ENGINE=InnoDB;

CREATE TABLE cita_medica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  mascota_id BIGINT UNSIGNED NOT NULL,
  propietario_id BIGINT UNSIGNED NOT NULL,
  veterinario_id BIGINT UNSIGNED NOT NULL,
  especialidad_id BIGINT UNSIGNED NOT NULL,
  tarifa_id BIGINT UNSIGNED NOT NULL,
  estado_cita_id BIGINT UNSIGNED NOT NULL,
  fecha_hora_inicio DATETIME NOT NULL,
  fecha_hora_fin DATETIME NOT NULL,
  motivo_consulta VARCHAR(255) NOT NULL,
  observaciones TEXT NULL,
  motivo_cancelacion VARCHAR(255) NULL,
  usuario_registro_id BIGINT UNSIGNED NOT NULL,
  fecha_creacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_modificacion DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  INDEX idx_cita_vet_fecha (veterinario_id, fecha_hora_inicio, fecha_hora_fin),
  INDEX idx_cita_mascota_fecha (mascota_id, fecha_hora_inicio, fecha_hora_fin),
  CONSTRAINT chk_cita_fechas CHECK (fecha_hora_fin > fecha_hora_inicio),
  CONSTRAINT fk_cita_mascota FOREIGN KEY (mascota_id) REFERENCES mascota(id),
  CONSTRAINT fk_cita_propietario FOREIGN KEY (propietario_id) REFERENCES propietario(id),
  CONSTRAINT fk_cita_veterinario FOREIGN KEY (veterinario_id) REFERENCES veterinario(id),
  CONSTRAINT fk_cita_especialidad FOREIGN KEY (especialidad_id) REFERENCES especialidad(id),
  CONSTRAINT fk_cita_tarifa FOREIGN KEY (tarifa_id) REFERENCES tarifa_servicio(id),
  CONSTRAINT fk_cita_estado FOREIGN KEY (estado_cita_id) REFERENCES estado_cita(id),
  CONSTRAINT fk_cita_usuario FOREIGN KEY (usuario_registro_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 4. INVENTARIO, LOTES, MOVIMIENTOS Y LOG DE CARGA MASIVA (Req. 1)
-- ----------------------------------------------------------------------------
-- Evolución de la tabla base `medicamento` entregada en el enunciado:
CREATE TABLE medicamento (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo VARCHAR(8) NOT NULL COMMENT 'Código alfanumérico obligatorio de 8 caracteres',
  nombre VARCHAR(100) NOT NULL,
  tipo_producto ENUM('MEDICAMENTO', 'UTENSILIO_INSUMO') NOT NULL DEFAULT 'MEDICAMENTO',
  registro_invima VARCHAR(60) NULL COMMENT 'Obligatorio cuando tipo_producto = MEDICAMENTO',
  descripcion TEXT NULL,
  presentacion VARCHAR(100) NULL,
  precio_compra_referencia DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  precio_venta_publico DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  cantidad_actual INT NOT NULL DEFAULT 0,
  stock_minimo INT NOT NULL DEFAULT 5,
  fecha_compra DATE NOT NULL,
  fecha_ingreso_inventario DATE NOT NULL,
  fecha_proximo_pedido DATE NULL,
  fecha_vence DATE NULL COMMENT 'Fecha próxima de referencia; el control exacto por lote vive en medicamento_lote',
  porcentaje_iva DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  fecha_creacion_registro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  fecha_modificacion_registro DATETIME NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY id (id),
  UNIQUE KEY nombre (nombre),
  UNIQUE KEY uk_medicamento_codigo (codigo),
  CONSTRAINT chk_med_codigo_len CHECK (CHAR_LENGTH(codigo) = 8),
  CONSTRAINT chk_med_stock_no_neg CHECK (cantidad_actual >= 0 AND stock_minimo >= 0),
  CONSTRAINT chk_med_precios CHECK (precio_compra_referencia >= 0 AND precio_venta_publico >= 0)
) ENGINE=InnoDB;

CREATE TABLE medicamento_lote (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  medicamento_id BIGINT UNSIGNED NOT NULL,
  numero_lote VARCHAR(50) NOT NULL,
  precio_compra DECIMAL(12,2) NOT NULL,
  cantidad_inicial INT NOT NULL,
  cantidad_disponible INT NOT NULL,
  fecha_ingreso DATE NOT NULL,
  fecha_vencimiento DATE NULL,
  activo TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (id),
  UNIQUE KEY uk_med_lote (medicamento_id, numero_lote),
  INDEX idx_lote_fefo (medicamento_id, activo, fecha_vencimiento),
  CONSTRAINT chk_lote_cant CHECK (cantidad_inicial > 0 AND cantidad_disponible >= 0),
  CONSTRAINT fk_lote_medicamento FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
) ENGINE=InnoDB;

CREATE TABLE log_carga_masiva_inventario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  usuario_id BIGINT UNSIGNED NOT NULL,
  nombre_archivo VARCHAR(180) NOT NULL,
  total_registros INT NOT NULL,
  registros_validos INT NOT NULL,
  registros_con_error INT NOT NULL,
  detalle_errores_json JSON NULL,
  fecha_cargue DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_log_carga_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 5. ATENCIÓN CLÍNICA, FÓRMULAS MÉDICAS Y DESPACHO/DISPENSACIÓN (Req. 3 y 5)
-- ----------------------------------------------------------------------------
CREATE TABLE atencion_medica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  cita_id BIGINT UNSIGNED NOT NULL,
  mascota_id BIGINT UNSIGNED NOT NULL,
  veterinario_id BIGINT UNSIGNED NOT NULL,
  motivo_consulta TEXT NOT NULL,
  sintomas TEXT NOT NULL,
  diagnostico TEXT NOT NULL,
  observaciones_medicas TEXT NULL,
  recomendaciones TEXT NULL,
  fecha_atencion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_atencion_cita (cita_id),
  CONSTRAINT fk_atencion_cita FOREIGN KEY (cita_id) REFERENCES cita_medica(id),
  CONSTRAINT fk_atencion_mascota FOREIGN KEY (mascota_id) REFERENCES mascota(id),
  CONSTRAINT fk_atencion_vet FOREIGN KEY (veterinario_id) REFERENCES veterinario(id)
) ENGINE=InnoDB;

CREATE TABLE formula_medica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  codigo_formula VARCHAR(30) NOT NULL,
  atencion_id BIGINT UNSIGNED NOT NULL,
  cita_id BIGINT UNSIGNED NOT NULL,
  mascota_id BIGINT UNSIGNED NOT NULL,
  veterinario_id BIGINT UNSIGNED NOT NULL,
  indicaciones_generales TEXT NULL,
  estado_despacho ENUM(
    'PENDIENTE_DESPACHO',
    'EN_PREPARACION',
    'DESPACHO_PARCIAL',
    'DESPACHADO',
    'PENDIENTE_DISPONIBILIDAD',
    'CANCELADO'
  ) NOT NULL DEFAULT 'PENDIENTE_DESPACHO',
  fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_formula_codigo (codigo_formula),
  CONSTRAINT fk_formula_atencion FOREIGN KEY (atencion_id) REFERENCES atencion_medica(id),
  CONSTRAINT fk_formula_cita FOREIGN KEY (cita_id) REFERENCES cita_medica(id),
  CONSTRAINT fk_formula_mascota FOREIGN KEY (mascota_id) REFERENCES mascota(id),
  CONSTRAINT fk_formula_vet FOREIGN KEY (veterinario_id) REFERENCES veterinario(id)
) ENGINE=InnoDB;

CREATE TABLE detalle_formula_medica (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  formula_id BIGINT UNSIGNED NOT NULL,
  medicamento_id BIGINT UNSIGNED NOT NULL,
  dosis VARCHAR(80) NOT NULL,
  frecuencia VARCHAR(80) NOT NULL,
  duracion VARCHAR(80) NOT NULL,
  via_administracion VARCHAR(60) NOT NULL,
  cantidad_prescrita INT NOT NULL,
  cantidad_dispensada INT NOT NULL DEFAULT 0,
  indicaciones_especiales TEXT NULL,
  PRIMARY KEY (id),
  CONSTRAINT chk_det_formula_cant CHECK (cantidad_prescrita > 0 AND cantidad_dispensada >= 0 AND cantidad_dispensada <= cantidad_prescrita),
  CONSTRAINT fk_det_formula_cab FOREIGN KEY (formula_id) REFERENCES formula_medica(id),
  CONSTRAINT fk_det_formula_med FOREIGN KEY (medicamento_id) REFERENCES medicamento(id)
) ENGINE=InnoDB;

CREATE TABLE despacho_medicamento (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  numero_despacho VARCHAR(30) NOT NULL,
  formula_id BIGINT UNSIGNED NOT NULL,
  usuario_despacho_id BIGINT UNSIGNED NOT NULL,
  estado ENUM(
    'PENDIENTE_DESPACHO',
    'EN_PREPARACION',
    'DESPACHO_PARCIAL',
    'DESPACHADO',
    'PENDIENTE_DISPONIBILIDAD',
    'CANCELADO'
  ) NOT NULL,
  observaciones TEXT NULL,
  revertido TINYINT(1) NOT NULL DEFAULT 0,
  motivo_reversion VARCHAR(255) NULL,
  usuario_reversion_id BIGINT UNSIGNED NULL,
  fecha_reversion DATETIME NULL,
  fecha_dispensacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_despacho_numero (numero_despacho),
  CONSTRAINT fk_despacho_formula FOREIGN KEY (formula_id) REFERENCES formula_medica(id),
  CONSTRAINT fk_despacho_usuario FOREIGN KEY (usuario_despacho_id) REFERENCES usuario(id),
  CONSTRAINT fk_despacho_rev_usuario FOREIGN KEY (usuario_reversion_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

CREATE TABLE detalle_despacho_medicamento (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  despacho_id BIGINT UNSIGNED NOT NULL,
  detalle_formula_id BIGINT UNSIGNED NOT NULL,
  medicamento_id BIGINT UNSIGNED NOT NULL,
  lote_id BIGINT UNSIGNED NOT NULL,
  cantidad_entregada INT NOT NULL,
  precio_unitario_aplicado DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_despacho_detalle_lote (despacho_id, detalle_formula_id, lote_id),
  CONSTRAINT chk_det_despacho_cant CHECK (cantidad_entregada > 0),
  CONSTRAINT fk_det_desp_cab FOREIGN KEY (despacho_id) REFERENCES despacho_medicamento(id),
  CONSTRAINT fk_det_desp_formula FOREIGN KEY (detalle_formula_id) REFERENCES detalle_formula_medica(id),
  CONSTRAINT fk_det_desp_med FOREIGN KEY (medicamento_id) REFERENCES medicamento(id),
  CONSTRAINT fk_det_desp_lote FOREIGN KEY (lote_id) REFERENCES medicamento_lote(id)
) ENGINE=InnoDB;

CREATE TABLE log_estado_despacho (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  formula_id BIGINT UNSIGNED NOT NULL,
  despacho_id BIGINT UNSIGNED NULL,
  estado_anterior VARCHAR(40) NULL,
  estado_nuevo VARCHAR(40) NOT NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  observacion VARCHAR(255) NULL,
  fecha_cambio DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT fk_log_est_formula FOREIGN KEY (formula_id) REFERENCES formula_medica(id),
  CONSTRAINT fk_log_est_despacho FOREIGN KEY (despacho_id) REFERENCES despacho_medicamento(id),
  CONSTRAINT fk_log_est_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

CREATE TABLE movimiento_inventario (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  medicamento_id BIGINT UNSIGNED NOT NULL,
  lote_id BIGINT UNSIGNED NULL,
  tipo_movimiento ENUM('ENTRADA_COMPRA', 'ENTRADA_CARGA_MASIVA', 'SALIDA_DISPENSACION', 'ENTRADA_REVERSION_DESPACHO', 'AJUSTE_ADMIN') NOT NULL,
  cantidad INT NOT NULL,
  stock_anterior INT NOT NULL,
  stock_nuevo INT NOT NULL,
  formula_id BIGINT UNSIGNED NULL,
  despacho_id BIGINT UNSIGNED NULL,
  usuario_id BIGINT UNSIGNED NOT NULL,
  observacion VARCHAR(255) NULL,
  fecha_movimiento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_mov_unico_despacho_lote (despacho_id, lote_id, tipo_movimiento),
  CONSTRAINT chk_mov_stock CHECK (cantidad > 0 AND stock_nuevo >= 0),
  CONSTRAINT fk_mov_med FOREIGN KEY (medicamento_id) REFERENCES medicamento(id),
  CONSTRAINT fk_mov_lote FOREIGN KEY (lote_id) REFERENCES medicamento_lote(id),
  CONSTRAINT fk_mov_formula FOREIGN KEY (formula_id) REFERENCES formula_medica(id),
  CONSTRAINT fk_mov_despacho FOREIGN KEY (despacho_id) REFERENCES despacho_medicamento(id),
  CONSTRAINT fk_mov_usuario FOREIGN KEY (usuario_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- 6. FACTURACIÓN Y PAGOS (Req. 3.4 y 3.5)
-- ----------------------------------------------------------------------------
CREATE TABLE factura (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  numero_factura VARCHAR(30) NOT NULL,
  cita_id BIGINT UNSIGNED NOT NULL,
  atencion_id BIGINT UNSIGNED NOT NULL,
  propietario_id BIGINT UNSIGNED NOT NULL,
  mascota_id BIGINT UNSIGNED NOT NULL,
  veterinario_id BIGINT UNSIGNED NOT NULL,
  especialidad_id BIGINT UNSIGNED NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  total_iva DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  descuento_autorizado DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  total_pagar DECIMAL(12,2) NOT NULL,
  saldo_pendiente DECIMAL(12,2) NOT NULL,
  estado_pago ENUM('PENDIENTE_PAGO', 'PAGO_PARCIAL', 'PAGADA', 'ANULADA') NOT NULL DEFAULT 'PENDIENTE_PAGO',
  motivo_anulacion VARCHAR(255) NULL,
  usuario_anulacion_id BIGINT UNSIGNED NULL,
  fecha_anulacion DATETIME NULL,
  usuario_generacion_id BIGINT UNSIGNED NOT NULL,
  fecha_generacion DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_factura_numero (numero_factura),
  UNIQUE KEY uk_factura_cita (cita_id),
  CONSTRAINT chk_factura_totales CHECK (subtotal >= 0 AND total_iva >= 0 AND descuento_autorizado >= 0 AND total_pagar >= 0 AND saldo_pendiente >= 0),
  CONSTRAINT fk_factura_cita FOREIGN KEY (cita_id) REFERENCES cita_medica(id),
  CONSTRAINT fk_factura_atencion FOREIGN KEY (atencion_id) REFERENCES atencion_medica(id),
  CONSTRAINT fk_factura_propietario FOREIGN KEY (propietario_id) REFERENCES propietario(id),
  CONSTRAINT fk_factura_mascota FOREIGN KEY (mascota_id) REFERENCES mascota(id),
  CONSTRAINT fk_factura_vet FOREIGN KEY (veterinario_id) REFERENCES veterinario(id),
  CONSTRAINT fk_factura_esp FOREIGN KEY (especialidad_id) REFERENCES especialidad(id),
  CONSTRAINT fk_factura_user_gen FOREIGN KEY (usuario_generacion_id) REFERENCES usuario(id),
  CONSTRAINT fk_factura_user_anu FOREIGN KEY (usuario_anulacion_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

CREATE TABLE detalle_factura (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  factura_id BIGINT UNSIGNED NOT NULL,
  tipo_item ENUM('SERVICIO_CONSULTA', 'MEDICAMENTO_DISPENSADO') NOT NULL,
  tarifa_id BIGINT UNSIGNED NULL,
  detalle_despacho_id BIGINT UNSIGNED NULL,
  descripcion VARCHAR(180) NOT NULL,
  cantidad INT NOT NULL,
  precio_unitario_historico DECIMAL(12,2) NOT NULL,
  porcentaje_iva_historico DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  valor_iva DECIMAL(12,2) NOT NULL DEFAULT 0.00,
  subtotal_linea DECIMAL(12,2) NOT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY uk_factura_detalle_despacho (factura_id, detalle_despacho_id),
  CONSTRAINT chk_det_factura CHECK (cantidad > 0 AND precio_unitario_historico >= 0),
  CONSTRAINT fk_det_fac_cab FOREIGN KEY (factura_id) REFERENCES factura(id),
  CONSTRAINT fk_det_fac_tarifa FOREIGN KEY (tarifa_id) REFERENCES tarifa_servicio(id),
  CONSTRAINT fk_det_fac_desp FOREIGN KEY (detalle_despacho_id) REFERENCES detalle_despacho_medicamento(id)
) ENGINE=InnoDB;

CREATE TABLE pago_factura (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  factura_id BIGINT UNSIGNED NOT NULL,
  metodo_pago ENUM('EFECTIVO', 'TARJETA', 'TRANSFERENCIA', 'NEQUI_DAVIPLATA') NOT NULL,
  monto_pagado DECIMAL(12,2) NOT NULL,
  referencia_transaccion VARCHAR(80) NULL,
  usuario_registro_id BIGINT UNSIGNED NOT NULL,
  fecha_pago DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  CONSTRAINT chk_pago_monto CHECK (monto_pagado > 0),
  CONSTRAINT fk_pago_factura FOREIGN KEY (factura_id) REFERENCES factura(id),
  CONSTRAINT fk_pago_usuario FOREIGN KEY (usuario_registro_id) REFERENCES usuario(id)
) ENGINE=InnoDB;

-- ----------------------------------------------------------------------------
-- DATOS SEMILLA INICIALES (ROLES Y ESTADOS)
-- ----------------------------------------------------------------------------
INSERT INTO rol (codigo, nombre, descripcion) VALUES
('ADMIN', 'Administrador del Sistema', 'Acceso total a configuración, tarifas, reportes y usuarios'),
('SECRETARIA', 'Secretaría / Recepción', 'Gestión administrativa de agenda, clientes y facturación'),
('VETERINARIO', 'Médico Veterinario', 'Calendario médico, atención clínica y generación de fórmulas'),
('DESPACHO_MEDICO', 'Despacho Médico', 'Consulta de inventario y dispensación transaccional de fórmulas');

INSERT INTO estado_cita (codigo, nombre, color_hex) VALUES
('PENDIENTE', 'Pendiente', '#F59E0B'),
('CONFIRMADA', 'Confirmada', '#2563EB'),
('CANCELADA', 'Cancelada', '#DC2626'),
('FINALIZADA', 'Finalizada', '#16A34A');
