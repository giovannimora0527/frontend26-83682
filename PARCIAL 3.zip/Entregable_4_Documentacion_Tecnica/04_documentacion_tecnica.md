# ENTREGABLE 4: DOCUMENTACIÓN TÉCNICA DE LA SOLUCIÓN

## 1. Arquitectura de la Solución
La solución implementa una arquitectura **Full Stack de 3 capas** desacoplada y contenerizada mediante **Docker Compose**:
* **Capa de Presentación (Frontend - Angular):** Interfaz responsiva con control dinámico de menú según el perfil autenticado (`ADMIN`, `SECRETARIA`, `VETERINARIO`, `DESPACHO_MEDICO`), vista de calendario interactivo, formularios reactivos con validación en cliente y descarga directa de binarios PDF/XLSX.
* **Capa de Negocio y Seguridad (Backend - Spring Boot 4 / Java 21):** API RESTful asegurada con **Spring Security + JWT** y autorización por anotaciones `@PreAuthorize` en cada endpoint. Las operaciones críticas (`confirmarDespacho`, `confirmarCargaMasiva`, `generarFactura`, `registrarPago`) están demarcadas con `@Transactional(rollbackFor = Exception.class)`.
* **Capa de Persistencia (MySQL 8.4):** Modelo relacional normalizado con integridad referencial (`FOREIGN KEY`), restricciones de dominio (`CHECK`), índices compuestos para consultas de solapamiento de agenda y Kardex inmutable.

---

## 2. Instrucciones de Instalación y Ejecución

### Requisitos Previos
* Docker Engine 24+ y Docker Compose v2+

### Pasos de Despliegue
1. Clonar el repositorio y ubicarse en la raíz del proyecto.
2. Levantar toda la infraestructura con un solo comando:
   ```bash
   docker compose up -d --build
   ```
3. Acceder a los servicios desplegados:
   * **Aplicación Web (Frontend):** `http://localhost:4200`
   * **API REST (Backend):** `http://localhost:8080/api/v1`
   * **Documentación Interactiva Swagger UI:** `http://localhost:8080/swagger-ui.html`
   * **Especificación OpenAPI JSON:** `http://localhost:8080/v3/api-docs`

---

## 3. Credenciales de Prueba por Rol (Entorno de Pruebas)
> *Nota: Todas las contraseñas corresponden exclusivamente a claves ficticias de laboratorio para evaluación académica.*

| Rol en el Sistema | Usuario | Contraseña de Prueba | Módulos Habilitados |
| :--- | :--- | :--- | :--- |
| `ADMIN` | `admin.clinica` | `TestAdmin#2026` | Acceso integral: inventario, carga masiva, especialidades, tarifas, citas, facturación, reportes y usuarios. |
| `SECRETARIA` | `recepcion.vet` | `TestSecre#2026` | Módulo clásico de citas, propietarios, mascotas, facturación y registro de pagos. |
| `VETERINARIO` | `dr.ramirez` | `TestVet#2026` | Calendario médico propio (día/semana/mes), atención clínica, historias clínicas y fórmulas médicas. |
| `DESPACHO_MEDICO` | `despacho.vet` | `TestDesp#2026` | Consulta de inventario (solo lectura) y módulo de despacho/dispensación de fórmulas. |

---

## 4. Resumen de Reglas de Negocio Implementadas
1. **Codificación e INVIMA:** Todo ítem posee un código único de 8 caracteres; los productos tipo `MEDICAMENTO` exigen registro INVIMA obligatorio, mientras los `UTENSILIO_INSUMO` lo permiten nulo.
2. **Separación Formulación / Dispensación:** La fórmula médica nunca descuenta stock; solo la confirmación en el módulo de despacho ejecuta la salida transaccional por lote bajo criterio **FEFO** (*First Expired, First Out*) y prohíbe stock negativo o entrega de productos vencidos.
3. **Agenda sin Conflictos:** Se bloquean citas superpuestas para un mismo veterinario o una misma mascota, citas a médicos inactivos o fuera de su franja horaria configurada.
4. **Facturación Histórica e Íntegra:** No se permite facturar dos veces la misma cita (`UNIQUE cita_id`), solo se cobran medicamentos efectivamente dispensados, los precios unitarios e IVA quedan congelados históricamente en el detalle y las anulaciones conservan trazabilidad sin borrado físico.
5. **Seguridad en Backend:** Cada petición valida token JWT y rol en servidor; un usuario `DESPACHO_MEDICO` recibe `HTTP 403 Forbidden` si intenta consumir endpoints clínicos, financieros o de edición de inventario.

---

## 5. Especificación Swagger / OpenAPI
Se adjunta el contrato `openapi_swagger_clinica_veterinaria.yaml` en esta carpeta, además del endpoint activo `/swagger-ui.html` configurado con `springdoc-openapi`.
